﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HarryPotter
{
    class Rawenclaw: House
    {
        

        public Rawenclaw()

        {
            HouseGhost = "Grå damen";
            Mascot = "Örn";
            Password = "en ensam trollkarl";
        }

        
    }
}
