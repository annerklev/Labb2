﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HarryPotter
{
    class Huffelpuff:House
    {
        

        public Huffelpuff()

        {
            HouseGhost = "Den Tjocke Munkbrodern";
            Mascot = "Grävling";
            Password = "en ensam trollkarl";
        }
    }
}
