﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HarryPotter
{
    class Gryffindor: House
    {
        

        public Gryffindor()

        {
            HouseGhost = "Huvudlöse Nick";
            Mascot = "Lejon";
            Password = "en ensam trollkarl";
        }

        
    }


    
}


