﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HarryPotter
{
    class Wizard 
    { public string BloodStatus { get; set; }
        public bool DeathEater { get; set; }
        public bool DubledoresArmy { get; set; }
        public string Name { get; set; }

        

    }


}











